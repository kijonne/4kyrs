﻿namespace ServerLB1.DTOs
{
    public class CreateQuestionDto
    {
        public string Text { get; set; } = null!;
        public string? Explanation { get; set; }
        public List<CreateOptionDto> Options { get; set; } = new();
    }
}
