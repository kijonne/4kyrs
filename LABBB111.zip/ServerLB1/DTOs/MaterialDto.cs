﻿namespace ServerLB1.DTOs
{
    public class MaterialDto
    {
        public int TopicId { get; set; }
        public string Title { get; set; } = null!;
        public string Type { get; set; } = null!;
        public string? Content { get; set; }
        public string? FileUrl { get; set; }
    }
}
