﻿namespace ServerLB1.DTOs
{
    public class SubmitTestDto
    {
        public List<SubmitAnswerDto> Answers { get; set; } = new();
    }
}
