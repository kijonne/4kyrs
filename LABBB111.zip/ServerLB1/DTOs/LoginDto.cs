﻿namespace ServerLB1.DTOs
{
    public class LoginDto
    {
        public string Login { get; set; } = null!;
        public string Password { get; set; } = null!;
    }
}
