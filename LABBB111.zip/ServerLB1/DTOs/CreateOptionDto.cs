﻿namespace ServerLB1.DTOs
{
    public class CreateOptionDto
    {
        public string Text { get; set; } = null!;
        public bool IsCorrect { get; set; }
    }
}
