﻿namespace ServerLB1.DTOs
{
    public class RegisterDto
    {
        public string Login { get; set; } = null!;
        public string Password { get; set; } = null!;
        public string FullName { get; set; } = null!;
        public string Role { get; set; } = null!; 
    }
}
