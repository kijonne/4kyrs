﻿namespace ServerLB1.DTOs
{
    public class CreateTestDto
    {
        public int TopicId { get; set; }
        public string Title { get; set; } = null!;
        public int TimeLimitSec { get; set; }
        public int QuestionsPerTry { get; set; }
        public List<CreateQuestionDto> Questions { get; set; } = new();
    }
}
