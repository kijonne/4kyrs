﻿namespace ServerLB1.DTOs
{
    public class ProgressDto
    {
        public int TimeSpentSec { get; set; }
    }
}
