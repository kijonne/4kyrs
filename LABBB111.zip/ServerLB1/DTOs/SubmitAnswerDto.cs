﻿namespace ServerLB1.DTOs
{
    public class SubmitAnswerDto
    {
        public int QuestionId { get; set; }
        public List<int>? SelectedOptionIds { get; set; }
        public string? TextAnswer { get; set; }
    }
}
