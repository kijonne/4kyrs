﻿namespace ServerLB1.Models
{
    public class Test
    {
        public int Id { get; set; }
        public int TopicId { get; set; }
        public string Title { get; set; }
        public int TimeLimitSec { get; set; }
        public int QuestionsPerTry { get; set; } = 10;

        public Topic Topic { get; set; }
        public ICollection<Question> Questions { get; set; } = new List<Question>();
    }
}
