﻿namespace ServerLB1.Models
{
    public class Material
    {
        public int Id { get; set; }
        public int TopicId { get; set; }
        public string Title { get; set; }
        public string Type { get; set; }
        public string Content { get; set; }
        public string? FileUrl { get; set; }

        public Topic? Topic { get; set; }
    }
}
