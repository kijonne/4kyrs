﻿namespace ServerLB1.Models
{
    public class Task
    {
        public int Id { get; set; }
        public int TopicId { get; set; }
        public string Type { get; set; }
        public string Title { get; set; }
        public string Question { get; set; }
        public string Hint { get; set; }
        public string Explanation { get; set; }
        public string Data { get; set; }

        public Topic? Topic { get; set; }
    }
}
