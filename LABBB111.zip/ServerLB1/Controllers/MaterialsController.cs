﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ServerLB1.Contexts;
using ServerLB1.DTOs;
using ServerLB1.Models;
using System.Security.Claims;

[ApiController]
[Route("api/materials")]
[Authorize]
public class MaterialsController : ControllerBase
{
    private readonly AppDbContext _db;

    public MaterialsController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] int? topicId)
    {
        var query = _db.Materials.AsQueryable();
        if (topicId.HasValue)
            query = query.Where(m => m.TopicId == topicId);

        return Ok(await query.ToListAsync());
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var material = await _db.Materials.FindAsync(id);
        return material == null ? NotFound() : Ok(material);
    }

    [HttpPost]
    [Authorize(Roles = "teacher")]
    public async Task<IActionResult> Create([FromBody] MaterialDto dto)
    {
        var material = new Material
        {
            TopicId = dto.TopicId,
            Title = dto.Title,
            Type = dto.Type,
            Content = dto.Content,
            FileUrl = dto.FileUrl
        };

        _db.Materials.Add(material);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = material.Id }, material);
    }

    [HttpPut("{id}")]
    [Authorize(Roles = "teacher")]
    public async Task<IActionResult> Update(int id, [FromBody] MaterialDto dto)
    {
        var material = await _db.Materials.FindAsync(id);
        if (material == null) return NotFound();

        material.TopicId = dto.TopicId;
        material.Title = dto.Title;
        material.Type = dto.Type;
        material.Content = dto.Content;
        material.FileUrl = dto.FileUrl;

        await _db.SaveChangesAsync();
        return Ok(material);
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "teacher")]
    public async Task<IActionResult> Delete(int id)
    {
        var material = await _db.Materials.FindAsync(id);
        if (material == null) return NotFound();

        _db.Materials.Remove(material);
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpGet("{id}/progress")]
    public async Task<IActionResult> GetProgress(int id)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        var progress = await _db.MaterialProgresses
            .FirstOrDefaultAsync(p => p.UserId == userId && p.MaterialId == id);

        if (progress == null)
            return Ok(new { materialId = id, isVisited = false, timeSpentSec = 0 });

        return Ok(new
        {
            materialId = progress.MaterialId,
            isVisited = progress.IsVisited,
            timeSpentSec = progress.TimeSpentSec,
            lastOpenedAt = progress.LastOpenedAt
        });
    }

    [HttpPost("{id}/progress")]
    public async Task<IActionResult> UpdateProgress(int id, [FromBody] ProgressDto dto)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        var progress = await _db.MaterialProgresses
            .FirstOrDefaultAsync(p => p.UserId == userId && p.MaterialId == id);

        if (progress == null)
        {
            progress = new MaterialProgress
            {
                UserId = userId,
                MaterialId = id,
                IsVisited = true,
                TimeSpentSec = dto.TimeSpentSec,
                LastOpenedAt = DateTime.UtcNow
            };
            _db.MaterialProgresses.Add(progress);
        }
        else
        {
            progress.IsVisited = true;
            progress.TimeSpentSec += dto.TimeSpentSec;
            progress.LastOpenedAt = DateTime.UtcNow;
        }

        await _db.SaveChangesAsync();
        return Ok();
    }

    [HttpGet("/api/progress")]
    public async Task<IActionResult> GetAllProgress()
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var list = await _db.MaterialProgresses
            .Where(p => p.UserId == userId)
            .ToListAsync();
        return Ok(list);
    }
}