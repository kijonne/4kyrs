﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ServerLB1.Contexts;
using ServerLB1.DTOs;
using ServerLB1.Models;

[ApiController]
[Route("api/tests")]
[Authorize]
public class TestsController : ControllerBase
{
    private readonly AppDbContext _db;

    public TestsController(AppDbContext db) => _db = db;

    // ===== Преподаватель =====

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] int? topicId)
    {
        var query = _db.Tests.AsQueryable();
        if (topicId.HasValue)
            query = query.Where(t => t.TopicId == topicId);

        return Ok(await query.ToListAsync());
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetFull(int id)
    {
        var test = await _db.Tests
            .Include(t => t.Questions)
                .ThenInclude(q => q.AnswerOptions)
            .FirstOrDefaultAsync(t => t.Id == id);

        return test == null ? NotFound() : Ok(test);
    }

    [HttpPost]
    [Authorize(Roles = "teacher")]
    public async Task<IActionResult> Create([FromBody] CreateTestDto dto)
    {
        var test = new Test
        {
            TopicId = dto.TopicId,
            Title = dto.Title,
            TimeLimitSec = dto.TimeLimitSec,
            QuestionsPerTry = dto.QuestionsPerTry
        };

        foreach (var qDto in dto.Questions)
        {
            var question = new Question
            {
                Text = qDto.Text,
                Explanation = qDto.Explanation
            };

            foreach (var opt in qDto.Options)
            {
                question.AnswerOptions.Add(new AnswerOption
                {
                    Text = opt.Text,
                    IsCorrect = opt.IsCorrect
                });
            }

            test.Questions.Add(question);
        }

        _db.Tests.Add(test);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetFull), new { id = test.Id }, test);
    }

    // ===== Студент =====

    [HttpPost("{id}/submit")]
    [Authorize(Roles = "student")]
    public async Task<IActionResult> Submit(int id, [FromBody] SubmitTestDto dto)
    {
        var test = await _db.Tests
            .Include(t => t.Questions)
                .ThenInclude(q => q.AnswerOptions)
            .FirstOrDefaultAsync(t => t.Id == id);

        if (test == null) return NotFound();

        int score = 0;
        var details = new List<object>();

        foreach (var answer in dto.Answers)
        {
            var question = test.Questions.FirstOrDefault(q => q.Id == answer.QuestionId);
            if (question == null) continue;

            bool isCorrect = false;

            if (answer.SelectedOptionIds != null && answer.SelectedOptionIds.Any())
            {
                var correctIds = question.AnswerOptions
                    .Where(o => o.IsCorrect)
                    .Select(o => o.Id)
                    .OrderBy(x => x)
                    .ToList();

                var selected = answer.SelectedOptionIds.OrderBy(x => x).ToList();
                isCorrect = correctIds.SequenceEqual(selected);
            }

            if (isCorrect) score++;

            details.Add(new
            {
                question_id = question.Id,
                is_correct = isCorrect,
                explanation = question.Explanation
            });
        }

        return Ok(new
        {
            score,
            max_score = test.Questions.Count,
            percent = test.Questions.Count == 0 ? 0 : score * 100 / test.Questions.Count,
            details
        });
    }
}