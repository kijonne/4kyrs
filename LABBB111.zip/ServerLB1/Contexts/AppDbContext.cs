﻿using Microsoft.EntityFrameworkCore;
using ServerLB1.Models;

namespace ServerLB1.Contexts
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<AnswerOption> AnswerOptions { get; set; }
        public DbSet<Material> Materials { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Test> Tests { get; set; }
        public DbSet<Topic> Topics { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Material>().Property(m => m.Content).HasMaxLength(500);
            modelBuilder.Entity<Material>().Property(m => m.FileUrl).HasMaxLength(500);

            modelBuilder.Entity<Question>().Property(q => q.Text).HasMaxLength(500);
            modelBuilder.Entity<Question>().Property(q => q.Explanation).HasMaxLength(400);

            modelBuilder.Entity<AnswerOption>().Property(a => a.Text).HasMaxLength(500);

            modelBuilder.Entity<Material>().Property(m => m.Title).IsRequired();
            modelBuilder.Entity<Material>().Property(m => m.Type).IsRequired();
            modelBuilder.Entity<Material>().Property(m => m.Content).IsRequired();

            modelBuilder.Entity<Question>().Property(q => q.Text).IsRequired();

            modelBuilder.Entity<AnswerOption>().Property(a => a.Text).IsRequired();
            modelBuilder.Entity<AnswerOption>().Property(a => a.IsCorrect).IsRequired();

            modelBuilder.Entity<User>().Property(u => u.Login).IsRequired();
            modelBuilder.Entity<User>().Property(u => u.PasswordHash).IsRequired();
            modelBuilder.Entity<User>().Property(u => u.FullName).IsRequired();
            modelBuilder.Entity<User>().Property(u => u.RoleId).IsRequired();

            modelBuilder.Entity<User>()
                        .HasOne(u => u.Role)
                        .WithMany()
                        .HasForeignKey(u => u.RoleId);

            modelBuilder.Entity<Material>()
                .HasOne(m => m.Topic)
                .WithMany()
                .HasForeignKey(m => m.TopicId);

            modelBuilder.Entity<Test>()
                .HasOne(t => t.Topic)
                .WithMany()
                .HasForeignKey(t => t.TopicId);

            modelBuilder.Entity<Question>()
                .HasOne(q => q.Test)
                .WithMany(t => t.Questions)
                .HasForeignKey(q => q.TestId);

            modelBuilder.Entity<AnswerOption>()
                .HasOne(a => a.Question)
                .WithMany(q => q.AnswerOptions)
                .HasForeignKey(a => a.QuestionId);
        }
    }
}
