﻿using CoursePlatform.Components.Models;

public class ApiService
{
    private readonly HttpClient _http;

    public ApiService(HttpClient http) => _http = http;

    public async Task<List<Topic>> GetTopicsAsync()
        => await _http.GetFromJsonAsync<List<Topic>>("api/topics") ?? new();

    public async Task<List<Material>> GetMaterialsAsync(int topicId)
        => await _http.GetFromJsonAsync<List<Material>>($"api/materials?topicId={topicId}") ?? new();

    public async Task<Material?> GetMaterialAsync(int id)
        => await _http.GetFromJsonAsync<Material>($"api/materials/{id}");

    public async Task<MaterialProgress?> GetProgressAsync(int materialId)
        => await _http.GetFromJsonAsync<MaterialProgress>($"api/materials/{materialId}/progress");

    public async Task UpdateProgressAsync(int materialId, int timeSpentSec)
    {
        await _http.PostAsJsonAsync($"api/materials/{materialId}/progress", new
        {
            TimeSpentSec = timeSpentSec
        });
    }

    public async Task<List<MaterialProgress>> GetAllProgressAsync()
        => await _http.GetFromJsonAsync<List<MaterialProgress>>("api/progress") ?? new();
}