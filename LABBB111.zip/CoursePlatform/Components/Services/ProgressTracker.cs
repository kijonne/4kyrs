﻿namespace CoursePlatform.Components.Services
{
    public class ProgressTracker
    {
    }
}
