﻿namespace CoursePlatform.Components.Models
{
    public class Material
    {
        public int Id { get; set; }
        public int TopicId { get; set; }
        public string Title { get; set; } = "";
        public string Type { get; set; } = ""; // text, html, pdf, video...
        public string? Content { get; set; }
        public string? FileUrl { get; set; }
    }
}
