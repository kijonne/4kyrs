﻿namespace CoursePlatform.Components.Models
{
    public class MaterialProgress
    {
        public int MaterialId { get; set; }
        public bool IsVisited { get; set; }
        public int TimeSpentSec { get; set; }
        public DateTime? LastOpenedAt { get; set; }
    }
}
