namespace LabWork11;

public partial class App : System.Windows.Application
{
}
