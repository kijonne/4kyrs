using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Windows;
using Microsoft.Data.Sqlite;
using Microsoft.Win32;

namespace LabWork11;

public partial class MainWindow : Window
{
    private readonly string _dbPath = Path.Combine(AppContext.BaseDirectory, "labwork11.db");
    private string? _currentUser;
    private string? _currentRole;

    public MainWindow()
    {
        InitializeComponent();
        InitializeDatabase();
        RefreshWindowsInfo();
        UpdateRoleControls();
    }

    private string ConnectionString => $"Data Source={_dbPath}";

    // -------------------- Часть 1. Аутентификация Windows --------------------

    private void RefreshWindows_Click(object sender, RoutedEventArgs e) => RefreshWindowsInfo();

    private void RefreshWindowsInfo()
    {
        try
        {
            using WindowsIdentity identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            bool isAdmin = principal.IsInRole(WindowsBuiltInRole.Administrator);

            WindowsUserText.Text = $"Пользователь: {identity.Name}";
            WindowsDomainText.Text = $"Домен / компьютер: {Environment.MachineName}";
            WindowsGroupText.Text = $"Группа локальных администраторов: {(isAdmin ? "Да" : "Нет")}";
            WindowsAdminButton.IsEnabled = isAdmin;
            WindowsMessage.Text = isAdmin
                ? "Доступ к административной функции разрешён."
                : "Недостаточно прав: функция доступна только администраторам.";
        }
        catch (Exception ex)
        {
            WindowsMessage.Text = $"Не удалось получить данные Windows: {ex.Message}";
        }
    }

    private void WindowsAdmin_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show("Вы открыли функцию, доступную членам группы Administrators.",
            "Проверка прав Windows", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    // -------------------- Часть 2. База данных и роли --------------------

    private void InitializeDatabase()
    {
        using var connection = new SqliteConnection(ConnectionString);
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText =
                """
                CREATE TABLE IF NOT EXISTS Users (
                    Username TEXT PRIMARY KEY,
                    PasswordHash TEXT NOT NULL,
                    PasswordSalt TEXT NOT NULL,
                    Role TEXT NOT NULL,
                    PublicKey TEXT NULL
                );
                """;
            command.ExecuteNonQuery();
        }

        AddDemoUserIfMissing(connection, "admin", "Admin123!", "Admin");
        AddDemoUserIfMissing(connection, "editor", "Editor123!", "Editor");
        AddDemoUserIfMissing(connection, "user", "User123!", "Viewer");
    }

    private static void AddDemoUserIfMissing(SqliteConnection connection, string username, string password, string role)
    {
        using var check = connection.CreateCommand();
        check.CommandText = "SELECT COUNT(*) FROM Users WHERE Username = $u";
        check.Parameters.AddWithValue("$u", username);
        if (Convert.ToInt32(check.ExecuteScalar()) > 0) return;

        byte[] salt = RandomNumberGenerator.GetBytes(16);
        byte[] hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 100_000, HashAlgorithmName.SHA256, 32);

        using var insert = connection.CreateCommand();
        insert.CommandText = """
            INSERT INTO Users (Username, PasswordHash, PasswordSalt, Role)
            VALUES ($u, $h, $s, $r)
            """;
        insert.Parameters.AddWithValue("$u", username);
        insert.Parameters.AddWithValue("$h", Convert.ToBase64String(hash));
        insert.Parameters.AddWithValue("$s", Convert.ToBase64String(salt));
        insert.Parameters.AddWithValue("$r", role);
        insert.ExecuteNonQuery();
    }

    private void Login_Click(object sender, RoutedEventArgs e)
    {
        string username = LoginBox.Text.Trim();
        string password = PasswordBox.Password;

        if (username.Length == 0 || password.Length == 0)
        {
            MessageBox.Show("Введите логин и пароль.");
            return;
        }

        using var connection = new SqliteConnection(ConnectionString);
        connection.Open();
        using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT PasswordHash, PasswordSalt, Role
            FROM Users WHERE Username = $u
            """;
        command.Parameters.AddWithValue("$u", username);

        using var reader = command.ExecuteReader();
        if (!reader.Read())
        {
            MessageBox.Show("Пользователь не найден или пароль неверный.");
            return;
        }

        byte[] savedHash = Convert.FromBase64String(reader.GetString(0));
        byte[] salt = Convert.FromBase64String(reader.GetString(1));
        string role = reader.GetString(2);
        byte[] enteredHash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 100_000, HashAlgorithmName.SHA256, 32);

        if (!CryptographicOperations.FixedTimeEquals(savedHash, enteredHash))
        {
            MessageBox.Show("Пользователь не найден или пароль неверный.");
            return;
        }

        _currentUser = username;
        _currentRole = role;
        DbStatusText.Text = $"Вход выполнен: {username}";
        RoleText.Text = $"Роль: {role}";
        UpdateRoleControls();
    }

    private void Logout_Click(object sender, RoutedEventArgs e)
    {
        _currentUser = null;
        _currentRole = null;
        PasswordBox.Clear();
        DbStatusText.Text = "Вы вышли из системы.";
        RoleText.Text = "Роль: нет";
        UpdateRoleControls();
    }

    private void UpdateRoleControls()
    {
        EditButton.IsEnabled = _currentRole is "Admin" or "Editor";
        AdminButton.IsEnabled = _currentRole == "Admin";
    }

    private void EditFeature_Click(object sender, RoutedEventArgs e)
    {
        if (_currentRole is not ("Admin" or "Editor"))
        {
            MessageBox.Show("Недостаточно прав. Нужна роль Editor или Admin.");
            return;
        }
        MessageBox.Show($"Функция редактора открыта. Пользователь: {_currentUser}");
    }

    private void AdminFeature_Click(object sender, RoutedEventArgs e)
    {
        if (_currentRole != "Admin")
        {
            MessageBox.Show("Недостаточно прав. Нужна роль Admin.");
            return;
        }
        MessageBox.Show("Административная функция открыта.");
    }

    // -------------------- Часть 3. Авторизация с RSA --------------------

    private void GenerateKeys_Click(object sender, RoutedEventArgs e)
    {
        string username = RsaUserBox.Text.Trim();
        if (username.Length == 0)
        {
            MessageBox.Show("Сначала введите имя существующего пользователя.");
            return;
        }

        try
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();

            using var check = connection.CreateCommand();
            check.CommandText = "SELECT COUNT(*) FROM Users WHERE Username = $u";
            check.Parameters.AddWithValue("$u", username);
            if (Convert.ToInt32(check.ExecuteScalar()) == 0)
            {
                MessageBox.Show("Такого пользователя нет. Используйте admin, editor или user.");
                return;
            }

            using RSA rsa = RSA.Create(2048);
            byte[] publicKey = rsa.ExportRSAPublicKey();
            byte[] privateKey = rsa.ExportRSAPrivateKey();

            var dialog = new SaveFileDialog
            {
                Title = "Сохранить закрытый RSA-ключ",
                Filter = "Файл ключа (*.key)|*.key|Все файлы (*.*)|*.*",
                FileName = $"{username}_private.key"
            };

            if (dialog.ShowDialog() != true) return;

            File.WriteAllBytes(dialog.FileName, privateKey);

            using var update = connection.CreateCommand();
            update.CommandText = "UPDATE Users SET PublicKey = $key WHERE Username = $u";
            update.Parameters.AddWithValue("$key", Convert.ToBase64String(publicKey));
            update.Parameters.AddWithValue("$u", username);
            update.ExecuteNonQuery();

            RsaGenerateStatus.Text = $"Ключи созданы. Закрытый ключ сохранён: {dialog.FileName}\nОткрытый ключ сохранён в базе данных.";
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка создания ключей: {ex.Message}");
        }
    }

    private void RsaLogin_Click(object sender, RoutedEventArgs e)
    {
        string username = RsaUserBox.Text.Trim();
        if (username.Length == 0)
        {
            MessageBox.Show("Введите имя пользователя.");
            return;
        }

        var dialog = new OpenFileDialog
        {
            Title = "Выберите файл закрытого RSA-ключа",
            Filter = "Файл ключа (*.key)|*.key|Все файлы (*.*)|*.*"
        };
        if (dialog.ShowDialog() != true) return;

        try
        {
            byte[] privateKey = File.ReadAllBytes(dialog.FileName);
            string? publicKeyText = null;
            string? role = null;

            using (var connection = new SqliteConnection(ConnectionString))
            {
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = "SELECT PublicKey, Role FROM Users WHERE Username = $u";
                command.Parameters.AddWithValue("$u", username);
                using var reader = command.ExecuteReader();

                if (!reader.Read())
                {
                    RsaLoginStatus.Text = "Пользователь не найден.";
                    return;
                }

                publicKeyText = reader.IsDBNull(0) ? null : reader.GetString(0);
                role = reader.GetString(1);
            }

            if (string.IsNullOrWhiteSpace(publicKeyText))
            {
                RsaLoginStatus.Text = "Для этого пользователя ещё не создана пара RSA-ключей.";
                return;
            }

            byte[] publicKey = Convert.FromBase64String(publicKeyText);
            byte[] token = RandomNumberGenerator.GetBytes(32);
            byte[] signature;

            using (RSA rsaPrivate = RSA.Create())
            {
                rsaPrivate.ImportRSAPrivateKey(privateKey, out _);
                signature = rsaPrivate.SignData(token, HashAlgorithmName.SHA256, RSASignaturePadding.Pss);
            }

            bool valid;
            using (RSA rsaPublic = RSA.Create())
            {
                rsaPublic.ImportRSAPublicKey(publicKey, out _);
                valid = rsaPublic.VerifyData(token, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pss);
            }

            if (valid)
            {
                _currentUser = username;
                _currentRole = role;
                RsaLoginStatus.Text = $"Успешная RSA-аутентификация: {username}. Роль в БД: {role}.";
                DbStatusText.Text = $"Вход выполнен через RSA: {username}";
                RoleText.Text = $"Роль: {role}";
                UpdateRoleControls();
            }
            else
            {
                RsaLoginStatus.Text = "Подпись неверна. Ключ не подходит этому пользователю.";
            }
        }
        catch (CryptographicException)
        {
            RsaLoginStatus.Text = "Ошибка проверки: выбран неверный или повреждённый файл ключа.";
        }
        catch (Exception ex)
        {
            RsaLoginStatus.Text = $"Ошибка авторизации: {ex.Message}";
        }
    }
}
