using Microsoft.EntityFrameworkCore;
using ProductService.Data;
using ProductService.Models;

var builder = WebApplication.CreateBuilder(args);

// Строка подключения берётся из переменной окружения CONNECTION_STRING
builder.Services.AddDbContext<ProductServiceDbContext>(options =>
    options.UseMySQL(Environment.GetEnvironmentVariable("CONNECTION_STRING")!));

var app = builder.Build();

var api = app.MapGroup("/api/products");

// GetProducts - список всех товаров
api.MapGet("/", async (ProductServiceDbContext db) =>
    Results.Ok(await db.Products.AsNoTracking().ToListAsync()));

// GetProduct(id) - один товар по идентификатору
api.MapGet("/{id:int}", async (int id, ProductServiceDbContext db) =>
    await db.Products.FindAsync(id) is Product product
        ? Results.Ok(product)
        : Results.NotFound());

// CreateProduct(Product) - создание товара
api.MapPost("/", async (Product product, ProductServiceDbContext db) =>
{
    product.Id = 0; // идентификатор назначает БД
    db.Products.Add(product);
    await db.SaveChangesAsync();
    return Results.Created($"/api/products/{product.Id}", product);
});

// IsAlive() - проверка работоспособности сервиса
api.MapGet("/isalive", () => Results.Ok("ProductService is alive"));

app.Run();
