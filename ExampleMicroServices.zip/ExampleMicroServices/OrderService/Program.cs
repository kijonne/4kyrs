using Microsoft.EntityFrameworkCore;
using OrderService.Data;
using OrderService.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<OrderServiceDbContext>(options =>
    options.UseMySQL(Environment.GetEnvironmentVariable("CONNECTION_STRING")!));

var app = builder.Build();

var api = app.MapGroup("/api/orders");

// GetOrders
api.MapGet("/", async (OrderServiceDbContext db) =>
    Results.Ok(await db.Orders.AsNoTracking().ToListAsync()));

// GetOrder(id)
api.MapGet("/{id:int}", async (int id, OrderServiceDbContext db) =>
    await db.Orders.FindAsync(id) is Order order
        ? Results.Ok(order)
        : Results.NotFound());

// CreateOrder(Order)
api.MapPost("/", async (Order order, OrderServiceDbContext db) =>
{
    if (order.Quantity <= 0)
        return Results.BadRequest("Quantity must be greater than zero");

    order.Id = 0;
    order.CreatedAt = DateTime.UtcNow;
    db.Orders.Add(order);
    await db.SaveChangesAsync();
    return Results.Created($"/api/orders/{order.Id}", order);
});

// IsAlive()
api.MapGet("/isalive", () => Results.Ok("OrderService is alive"));

app.Run();
