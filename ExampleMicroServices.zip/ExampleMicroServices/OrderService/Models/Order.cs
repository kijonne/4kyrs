namespace OrderService.Models;

public class Order
{
    public int Id { get; set; }
    // Идентификатор товара хранится как обычное число.
    // Внешнего ключа на таблицу Products нет: БД сервисов независимы.
    public int ProductId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal TotalPrice { get; set; }
    public DateTime CreatedAt { get; set; }
}
