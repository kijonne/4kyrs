CREATE TABLE IF NOT EXISTS `Products` (
    `Id` int NOT NULL AUTO_INCREMENT,
    `Name` varchar(100) NOT NULL,
    `Description` varchar(500) NULL,
    `Price` decimal(18,2) NOT NULL,
    `Stock` int NOT NULL,
    CONSTRAINT `PK_Products` PRIMARY KEY (`Id`)
);

INSERT INTO `Products` (`Name`, `Description`, `Price`, `Stock`) VALUES
('Ноутбук', 'Ноутбук 15.6 дюймов', 54990.00, 10),
('Мышь', 'Беспроводная оптическая мышь', 890.00, 100),
('Клавиатура', 'Механическая клавиатура', 3490.00, 40);
