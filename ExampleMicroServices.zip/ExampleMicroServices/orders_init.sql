CREATE TABLE IF NOT EXISTS `Orders` (
    `Id` int NOT NULL AUTO_INCREMENT,
    `ProductId` int NOT NULL,
    `CustomerName` varchar(100) NOT NULL,
    `Quantity` int NOT NULL,
    `TotalPrice` decimal(18,2) NOT NULL,
    `CreatedAt` datetime(6) NOT NULL,
    CONSTRAINT `PK_Orders` PRIMARY KEY (`Id`)
);

INSERT INTO `Orders` (`ProductId`, `CustomerName`, `Quantity`, `TotalPrice`, `CreatedAt`) VALUES
(1, 'Иванов Иван', 1, 54990.00, NOW()),
(2, 'Петров Пётр', 2, 1780.00, NOW());
