Запуск на ВМ (замените IP и логин на свои):

1) Копирование:  scp -r ExampleMicroServices ispp3110@10.9.1.150:/home/ispp3110/
2) На ВМ:        cd ~/ExampleMicroServices && sudo docker compose up -d --build
3) Проверка:     http://10.9.1.150:5000/products/   и   http://10.9.1.150:5000/orders/

Если IP ВМ другой, поменяйте BaseUrl в ApiGateway/ocelot.json.
